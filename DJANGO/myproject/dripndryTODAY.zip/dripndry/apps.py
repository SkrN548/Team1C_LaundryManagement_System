from django.apps import AppConfig

class DripndryConfig(AppConfig):
    name = 'dripndry'
