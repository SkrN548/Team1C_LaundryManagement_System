from django.contrib import admin
from dripndry.models import dripndry
from dripndry.models import order



# Register your models here.
admin.site.register(dripndry)
admin.site.register(order)

